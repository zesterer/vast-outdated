//CMake handles this
#define VAST_VERSION_MAJOR 0
#define VAST_VERSION_MINOR 0
#define VAST_VERSION_BUILD 0

#define VAST_DEBUG_ENABLED true
